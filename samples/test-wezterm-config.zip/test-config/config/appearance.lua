-- Appearance settings
local M = {}

-- Colors configuration
M.colors = {
  foreground = '#c0caf5',
  background = '#1a1b26',
  cursor_bg = '#c0caf5',
  cursor_fg = '#1a1b26',
}

return M
